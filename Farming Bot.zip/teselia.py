from engine import press, repeat
import engine as e

# GUIA DE USO
#
# ESTE BOT SE USA EN BASE A SEGUNDOS
# Y SE DIVIDE EN SECCIONES DEL 1 AL 24.
# LAS SECCIONES AVANZAN AUTOMATICAMENTE
# DESDE EL NUMERO PUESTO.
# ---------------------------------------------
# LA FUNCION press() FUNCIONA DE ESTA FORMA:
# press(TECLA, PRESIONADO)
# ---------------------------------------------
# LA FUNCION repeat() FUNCIONA DE ESTA FORMA:
# repeat(TECLA, PRESIONADO, VECES,
#        INTERVALO, TIEMPO DE ESPERA)
# ---------------------------------------------
#
# UN PASO CAMINADO SON 0.45 SEGUNDOS
# UNA CAJA DE TEXTO DURA APROX. 4 SEGUNDOS


##### TESELIA #####


#Casa del jugador 1
repeat(e._z, 0.1, 4, 4, 2)
repeat(e._z, 0.1, 3, 4, 1)
repeat(e._z, 0.1, 7, 4, 1)
press(e.down, 0.45)
repeat(e._z, 0.1, 2, 1.8, 3)
press(e.left, 0.1)
repeat(e._z, 0.1, 2, 0.4, 0)
press(e.up, 0)
press(e._z, 3.6)
repeat(e._z, 0.1, 12, 4, 10)



