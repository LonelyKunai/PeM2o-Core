#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de prueba para la detección optimizada de Pokémon
Demuestra el uso de la nueva función init_combat_optimized con control de tiempo
"""

import cv2
import numpy as np
import pyautogui
import time
from engine import init_combat_optimized, init_combat
from config import DETECTION_CONFIG, TEST_CONFIGS, MENU_CONFIG, DEFAULT_TEST_CONFIG

def mostrar_menu_configuraciones():
    """
    Muestra el menú de configuraciones disponibles
    """
    print("\n" + "=" * 60)
    print("🔧 CONFIGURACIONES DE PRUEBA DISPONIBLES")
    print("=" * 60)
    
    for config in MENU_CONFIG['opciones_configuracion']:
        print(f"{config['id']}. {config['name']}")
        print(f"   {config['description']}")
        print()
    
    return MENU_CONFIG['opciones_configuracion']

def obtener_configuracion_personalizada():
    """
    Permite al usuario configurar parámetros manualmente
    """
    print("\n🔧 CONFIGURACIÓN PERSONALIZADA")
    print("-" * 40)
    
    # Obtener configuración por defecto
    default_config = TEST_CONFIGS[DEFAULT_TEST_CONFIG]
    
    try:
        batch_size = int(input(f"📦 Tamaño del lote (imágenes) [{default_config['batch_size']}]: ") or str(default_config['batch_size']))
        max_time = float(input(f"⏱️  Tiempo máximo por lote (segundos) [{default_config['max_time_per_batch']}]: ") or str(default_config['max_time_per_batch']))
        threshold = float(input(f"🎯 Umbral de detección (0.0-1.0) [{default_config['threshold']}]: ") or str(default_config['threshold']))
        
        return {
            'name': 'Configuración Personalizada',
            'batch_size': batch_size,
            'max_time_per_batch': max_time,
            'threshold': threshold
        }
    except ValueError:
        print("❌ Error: Valores inválidos. Usando configuración estándar.")
        return {
            'name': 'Configuración Estándar (fallback)',
            'batch_size': default_config['batch_size'],
            'max_time_per_batch': default_config['max_time_per_batch'],
            'threshold': default_config['threshold']
        }

def test_optimized_search(config_id=None):
    """
    Prueba la función de búsqueda optimizada con diferentes configuraciones
    """
    print("=" * 60)
    print("🧪 PRUEBA DE DETECCIÓN OPTIMIZADA DE POKÉMON")
    print("=" * 60)
    
    # Capturar pantalla
    print("📸 Capturando pantalla...")
    screenshot = pyautogui.screenshot()
    screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    print("✅ Pantalla capturada exitosamente")
    
    # Obtener configuraciones desde config.py
    configuraciones_predefinidas = [TEST_CONFIGS['rapida'], TEST_CONFIGS['estandar'], TEST_CONFIGS['agresiva']]
    
    # Si no se especifica config_id, mostrar menú
    if config_id is None:
        configuraciones_menu = mostrar_menu_configuraciones()
        
        while True:
            try:
                opcion = input(f"\n🎯 Selecciona una opción (1-5) [{DEFAULT_TEST_CONFIG}]: ").strip()
                if not opcion:
                    opcion = str(TEST_CONFIGS[DEFAULT_TEST_CONFIG]['id'])
                
                opcion = int(opcion)
                
                if opcion == 4:  # Configuración personalizada
                    config = obtener_configuracion_personalizada()
                    break
                elif opcion == 5:  # Todas las configuraciones
                    ejecutar_todas_las_configuraciones(screenshot, configuraciones_predefinidas)
                    return
                elif 1 <= opcion <= 3:
                    # Mapear opción a configuración
                    config_keys = ['rapida', 'estandar', 'agresiva']
                    config = TEST_CONFIGS[config_keys[opcion - 1]]
                    break
                else:
                    print("❌ Opción inválida. Intenta de nuevo.")
            except ValueError:
                print("❌ Por favor, ingresa un número válido.")
            except KeyboardInterrupt:
                print("\n❌ Operación cancelada por el usuario.")
                return
    else:
        # Usar configuración específica
        if 1 <= config_id <= 3:
            config_keys = ['rapida', 'estandar', 'agresiva']
            config = TEST_CONFIGS[config_keys[config_id - 1]]
        else:
            print("❌ ID de configuración inválido. Usando configuración estándar.")
            config = TEST_CONFIGS[DEFAULT_TEST_CONFIG]
    
    # Ejecutar prueba con la configuración seleccionada
    ejecutar_prueba_configuracion(screenshot, config)

def ejecutar_prueba_configuracion(screenshot, config):
    """
    Ejecuta una prueba con una configuración específica
    """
    print(f"\n🔧 PRUEBA: {config['name']}")
    print("-" * 50)
    print(f"📦 Lote: {config['batch_size']} imágenes")
    print(f"⏱️  Tiempo máximo: {config['max_time_per_batch']}s por lote")
    print(f"🎯 Umbral: {config['threshold']}")
    print("-" * 50)
    print("🔍 Iniciando detección... (El filename se mostrará si se encuentra similitud)")
    print("-" * 50)
    
    start_time = time.time()
    
    # Ejecutar detección optimizada
    result = init_combat_optimized(
        screenshot=screenshot,
        threshold=config['threshold'],
        batch_size=config['batch_size'],
        max_time_per_batch=config['max_time_per_batch']
    )
    
    elapsed_time = time.time() - start_time
    
    print("-" * 50)
    print(f"📊 Resultado: {'✅ Pokémon detectado' if result else '❌ No se detectó Pokémon'}")
    print(f"⏱️  Tiempo total: {elapsed_time:.2f} segundos")
    print(f"📈 Velocidad: {elapsed_time/config['batch_size']:.3f}s por imagen")
    
    if result:
        print("💡 Nota: El filename del Pokémon detectado se mostró arriba durante la detección")
    else:
        print("💡 Nota: No se encontraron similitudes que superen el umbral configurado")

def ejecutar_todas_las_configuraciones(screenshot, configuraciones):
    """
    Ejecuta todas las configuraciones automáticamente
    """
    print("\n🚀 EJECUTANDO TODAS LAS CONFIGURACIONES")
    print("=" * 60)
    
    for i, config in enumerate(configuraciones, 1):
        print(f"\n📋 Configuración {i}/{len(configuraciones)}")
        ejecutar_prueba_configuracion(screenshot, config)
        
        if i < len(configuraciones):
            print("⏳ Esperando 2 segundos antes de la siguiente prueba...")
            time.sleep(2)

def test_timing_limits():
    """
    Prueba los límites de tiempo por imagen
    """
    print("\n" + "=" * 60)
    print("⏱️  PRUEBA DE LÍMITES DE TIEMPO POR IMAGEN")
    print("=" * 60)
    
    # Capturar pantalla
    print("📸 Capturando pantalla...")
    screenshot = pyautogui.screenshot()
    screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    
    # Probar con límite muy estricto
    print("\n🔧 Probando con límite de 100ms por imagen...")
    print("💡 Nota: El filename se mostrará si se encuentra similitud")
    start_time = time.time()
    
    result = init_combat_optimized(
        screenshot=screenshot,
        threshold=0.8,  # Umbral alto para detección rápida
        batch_size=5,   # Lote pequeño
        max_time_per_batch=1.0  # 1 segundo por lote
    )
    
    elapsed_time = time.time() - start_time
    print(f"📊 Resultado: {'✅ Pokémon detectado' if result else '❌ No se detectó Pokémon'}")
    print(f"⏱️  Tiempo total: {elapsed_time:.2f} segundos")
    
    if result:
        print("💡 Nota: El filename del Pokémon detectado se mostró durante la detección")
    else:
        print("💡 Nota: No se encontraron similitudes en el tiempo límite configurado")

def compare_methods():
    """
    Compara el método original vs el optimizado
    """
    print("\n" + "=" * 60)
    print("⚖️  COMPARACIÓN: MÉTODO ORIGINAL vs OPTIMIZADO")
    print("=" * 60)
    
    # Capturar pantalla
    print("📸 Capturando pantalla...")
    screenshot = pyautogui.screenshot()
    screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    
    # Método original
    print("\n🔧 Probando método original...")
    print("💡 Nota: El filename se mostrará si se encuentra similitud")
    start_time = time.time()
    result_original = init_combat(screenshot, threshold=0.65)
    time_original = time.time() - start_time
    
    print(f"📊 Método original: {'✅ Pokémon detectado' if result_original else '❌ No se detectó Pokémon'}")
    print(f"⏱️  Tiempo: {time_original:.2f} segundos")
    
    # Método optimizado
    print("\n🔧 Probando método optimizado...")
    print("💡 Nota: El filename se mostrará si se encuentra similitud")
    start_time = time.time()
    result_optimized = init_combat_optimized(
        screenshot=screenshot,
        threshold=0.65,
        batch_size=20,
        max_time_per_batch=5.0
    )
    time_optimized = time.time() - start_time
    
    print(f"📊 Método optimizado: {'✅ Pokémon detectado' if result_optimized else '❌ No se detectó Pokémon'}")
    print(f"⏱️  Tiempo: {time_optimized:.2f} segundos")
    
    # Comparación
    print(f"\n📈 Mejora de velocidad: {((time_original - time_optimized) / time_original * 100):.1f}%")
    print(f"⚡ Factor de mejora: {time_original / time_optimized:.2f}x")
    
    # Información adicional sobre detecciones
    if result_original or result_optimized:
        print("\n💡 Los filenames de los Pokémon detectados se mostraron durante la detección")
    else:
        print("\n💡 No se detectaron Pokémon con ninguno de los métodos")

def mostrar_menu_principal():
    """
    Muestra el menú principal del programa
    """
    print("\n" + "=" * 60)
    print("🤖 SISTEMA DE PRUEBAS DE DETECCIÓN DE POKÉMON")
    print("=" * 60)
    
    for opcion in MENU_CONFIG['opciones_principales']:
        emoji = "🧪" if opcion['id'] == 1 else "⏱️" if opcion['id'] == 2 else "⚖️" if opcion['id'] == 3 else "🔧" if opcion['id'] == 4 else "🚀" if opcion['id'] == 5 else "❌"
        print(f"{opcion['id']}. {emoji} {opcion['name']} - {opcion['description']}")
    
    # Agregar opción de información
    print("6. 📋 Información sobre detección de filenames")
    
    print("=" * 60)

def mostrar_informacion_deteccion():
    """
    Muestra información sobre cómo funciona la detección de filenames
    """
    print("\n" + "=" * 60)
    print("📋 INFORMACIÓN SOBRE DETECCIÓN DE FILENAMES")
    print("=" * 60)
    print("🔍 Cuando se ejecuta una detección:")
    print("   • Se analizan todas las imágenes en la carpeta 'mons/'")
    print("   • Para cada imagen que supere el umbral de similitud:")
    print("     - Se muestra el filename completo (ej: '649-chill.png')")
    print("     - Se muestra el nivel de confianza (0.0 - 1.0)")
    print("     - Se muestra la escala y posición de detección")
    print("     - Se muestra el tiempo de detección en milisegundos")
    print("   • Si no se encuentra similitud, no se muestra filename")
    print("\n💡 Ejemplo de salida cuando se detecta:")
    print("   🎯 ¡POKÉMON DETECTADO! 649-chill.png")
    print("   📊 Confianza: 0.856 | Escala: 1.0x | Posición: (450, 200)")
    print("   ⏱️  Tiempo de detección: 23.4ms")
    print("=" * 60)

def ejecutar_todas_las_pruebas():
    """
    Ejecuta todas las pruebas del sistema
    """
    print("\n🚀 EJECUTANDO TODAS LAS PRUEBAS AUTOMÁTICAMENTE")
    print("=" * 60)
    
    # Prueba optimizada con configuración estándar
    print(f"\n📋 1/3 - Prueba de detección optimizada ({DEFAULT_TEST_CONFIG})")
    test_optimized_search(config_id=TEST_CONFIGS[DEFAULT_TEST_CONFIG]['id'])
    
    # Prueba de límites de tiempo
    print("\n📋 2/3 - Prueba de límites de tiempo")
    test_timing_limits()
    
    # Comparación de métodos
    print("\n📋 3/3 - Comparación de métodos")
    compare_methods()
    
    print("\n" + "=" * 60)
    print("✅ TODAS LAS PRUEBAS COMPLETADAS")
    print("=" * 60)


if __name__ == "__main__":
    try:
        while True:
            mostrar_menu_principal()
            
            try:
                opcion = input("\n🎯 Selecciona una opción (0-6): ").strip()
                if not opcion:
                    opcion = "1"  # Opción por defecto
                
                opcion = int(opcion)
                
                if opcion == 0:
                    print("\n👋 ¡Hasta luego!")
                    break
                elif opcion == 1:
                    test_optimized_search()
                elif opcion == 2:
                    test_timing_limits()
                elif opcion == 3:
                    compare_methods()
                elif opcion == 4:
                    mostrar_menu_configuraciones()
                    input("\n⏸️  Presiona Enter para continuar...")
                elif opcion == 5:
                    ejecutar_todas_las_pruebas()
                elif opcion == 6:
                    mostrar_informacion_deteccion()
                    input("\n⏸️  Presiona Enter para continuar...")
                else:
                    print("❌ Opción inválida. Intenta de nuevo.")
                
                if opcion in [1, 2, 3, 5]:
                    input("\n⏸️  Presiona Enter para volver al menú principal...")
                    
            except ValueError:
                print("❌ Por favor, ingresa un número válido.")
            except KeyboardInterrupt:
                print("\n❌ Operación cancelada por el usuario.")
                break
        
    except KeyboardInterrupt:
        print("\n❌ Programa interrumpido por el usuario")
    except Exception as e:
        print(f"\n❌ Error durante la ejecución: {e}")
        import traceback
        traceback.print_exc()
