# Configuración del Bot de Farming de Pokémon para PokéMMO
# ========================================================

# CONFIGURACIÓN DE DETECCIÓN DE IMÁGENES
DETECTION_CONFIG = {
    # Configuración de procesamiento de color
    'color_processing': {
        'use_color': True,             # Usar detección a color (BGR)
        'color_mode': 'BGR',           # Modo de color: BGR, RGB, HSV
        'preserve_alpha': False,       # Preservar canal alpha si existe
        'color_enhancement': True      # Mejorar contraste de color
    },
    
    # Umbrales de confianza para diferentes tipos de detección
    'thresholds': {
        'target': 0.35,        # Umbral para imagen objetivo
        'horde': 0.6,          # Umbral más estricto para horda
        'overview': 0.3,       # Umbral más bajo para overview
        'pc': 0.9,             # Umbral muy alto para PC left/right
        'stairs': 0.4,         # Umbral para stairs
        'login': 0.45,         # Umbral bajo para login screens
        'pokemon': 0.65        # Umbral para detección de Pokémon
    },
    
    # Configuración de tiempo para detección optimizada
    'timing': {
        'max_detection_time': 25.0,      # Tiempo máximo total de detección (segundos)
        'max_time_per_image': 0.25,     # Tiempo máximo por imagen (250ms)
        'max_time_per_batch': 3.0,      # Tiempo máximo por lote de imágenes (segundos)
        'batch_size': 20,               # Número de imágenes por lote
        'check_interval': 0.005           # Intervalo entre verificaciones (segundos)
    },
    
    # Configuración de escalas para template matching
    'scales': [1.0],  # Solo escala 1.0x para máxima velocidad
    
    # Configuración de redimensionamiento
    'resize': {
        'max_template_size': 200,       # Tamaño máximo de template antes de redimensionar
        'min_template_size': 30,        # Tamaño mínimo de template
        'max_screen_ratio': 0.6         # Máxima proporción de pantalla que puede ocupar un template
    }
}

# CONFIGURACIÓN DE SECUENCIAS DE TECLAS
KEY_SEQUENCES = {
    'logout': ['esc', 'down', 'down', 'down', 'down', 'z', 'z'],
    'login': ['z', 'z'],
    'combat': ['up', 'left', 'z', 'z'],
    'horde': ['down', 'right', 'z'],
    'pp_restore': ['x', 'right', 'right', 'right', 'z'],
    'leppa_berry': ['4', 'z', 'z', 'z'],
    'alt_sequence': ['left', 'right', 'left', 'right', 'x'],
    'pc_1': ['down'],
    'pc_2': ['1', 'right', 'down'],
    'stairs_i6': ['down', 'right']
}

# CONFIGURACIÓN DE PAUSAS Y TIMEOUTS
TIMING_CONFIG = {
    'pause_interval': 10,               # Minutos entre pausas normales
    'pause_duration': (30, 90),         # Rango de duración de pausa (segundos)
    'logout_interval': 10,              # Horas entre logouts
    'login_delay': (75, 120),           # Rango de minutos de espera antes de login
    'combat_delay': 3,                  # Segundos de espera después de detectar combate
    'sequence_delay': (12, 40),         # Rango de milisegundos para presionar teclas
    'move_delay': (24, 50),             # Rango de milisegundos para movimientos
    'pc_delay': 1.4,                    # Segundos para secuencias de PC
    'pc_2_delay': 2.6,                  # Segundos para secuencia PC 2
    'stairs_delay': 1.0                 # Segundos para secuencia de stairs
}

# CONFIGURACIÓN DE DETECCIÓN DE VENTANA
WINDOW_CONFIG = {
    'window_title': 'PokeMMO',
    'fallback_resolution': (1920, 1080),
    'combat_area': {
        'y_start': 0.7,     # 70% desde arriba
        'y_end': 0.95,      # 95% desde arriba
        'x_start': 0.1,     # 10% desde la izquierda
        'x_end': 0.9        # 90% desde la derecha
    }
}

# CONFIGURACIÓN DE OCR
OCR_CONFIG = {
    'tesseract_config': '--psm 6 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',
    'fallback_config': '--psm 6',
    'text_patterns': {
        'fight': ['lucha', 'fight'],
        'pokemon': ['pokémon', 'pokemon'],
        'bag': ['mochila', 'bag'],
        'run': ['huida', 'run']
    }
}

# CONFIGURACIÓN DE LOGGING
LOGGING_CONFIG = {
    'level': 'INFO',
    'format': '%(asctime)s - %(levelname)s - %(message)s',
    'show_progress_every': 50,          # Mostrar progreso cada N imágenes
    'show_batch_stats': True,           # Mostrar estadísticas de lotes
    'show_timing_warnings': True        # Mostrar advertencias de tiempo
}

# CONFIGURACIÓN DE ARCHIVOS
FILE_CONFIG = {
    'mons_directory': 'mons',
    'image_extensions': ['.png', '.jpg', '.jpeg', '.webp'],
    'priority_keywords': ['grs', 'grass'],  # Palabras clave para priorizar Pokémon
    'screenshot_format': 'BGR'  # Formato de captura de pantalla
}

# CONFIGURACIONES DE PRUEBA PARA DETECCIÓN OPTIMIZADA
TEST_CONFIGS = {
    'rapida': {
        'id': 1,
        'name': 'Configuración Rápida',
        'description': '10 imágenes, 2s por lote, threshold 0.7',
        'batch_size': 10,
        'max_time_per_batch': 2.0,
        'threshold': 0.65
    },
    'estandar': {
        'id': 2,
        'name': 'Configuración Estándar',
        'description': '20 imágenes, 5s por lote, threshold 0.65',
        'batch_size': 20,
        'max_time_per_batch': 5.0,
        'threshold': 0.65
    },
    'agresiva': {
        'id': 3,
        'name': 'Configuración Agresiva',
        'description': '100 imágenes, 9s por lote, threshold 0.4',
        'batch_size': 100,
        'max_time_per_batch': 9.0,
        'threshold': 0.55
    },
    'personalizada': {
        'id': 4,
        'name': 'Configuración Personalizada',
        'description': 'Permite configurar parámetros manualmente',
        'batch_size': None,
        'max_time_per_batch': None,
        'threshold': None
    },
    'todas': {
        'id': 5,
        'name': 'Todas las configuraciones',
        'description': 'Ejecuta todas las configuraciones automáticamente',
        'batch_size': None,
        'max_time_per_batch': None,
        'threshold': None
    }
}

# CONFIGURACIÓN POR DEFECTO PARA PRUEBAS
DEFAULT_TEST_CONFIG = 'estandar'

# CONFIGURACIÓN DE MENÚS
MENU_CONFIG = {
    'opciones_principales': [
        {'id': 1, 'name': 'Prueba de detección optimizada', 'description': 'Con selección de configuración'},
        {'id': 2, 'name': 'Prueba de límites de tiempo', 'description': 'Prueba límites de tiempo por imagen'},
        {'id': 3, 'name': 'Comparación de métodos', 'description': 'Original vs optimizado'},
        {'id': 4, 'name': 'Mostrar configuraciones', 'description': 'Solo mostrar configuraciones disponibles'},
        {'id': 5, 'name': 'Ejecutar todas las pruebas', 'description': 'Automáticamente'},
        {'id': 0, 'name': 'Salir', 'description': 'Terminar el programa'}
    ],
    'opciones_configuracion': [
        {'id': 1, 'name': 'Configuración Rápida', 'description': '10 imágenes, 2s por lote, threshold 0.7'},
        {'id': 2, 'name': 'Configuración Estándar', 'description': '20 imágenes, 5s por lote, threshold 0.65'},
        {'id': 3, 'name': 'Configuración Agresiva', 'description': '50 imágenes, 10s por lote, threshold 0.6'},
        {'id': 4, 'name': 'Configuración Personalizada', 'description': 'Permite configurar parámetros manualmente'},
        {'id': 5, 'name': 'Todas las configuraciones', 'description': 'Ejecuta todas las configuraciones automáticamente'}
    ]
}