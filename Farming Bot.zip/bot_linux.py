import numpy as np
import random
import time
import pyautogui
from datetime import datetime, timedelta

class ImageBot:
    def __init__(self, target_image_path, target_horde_path, target_image_night_path, target_horde_night_path, target_no_pp_path, target_no_pp_night_path, overview_path, pokecenter_path, pc_left_path, pc_right_path, stairs_i6_path, login_screen_path, login_2_path):
        # Guardar rutas de imágenes
        self.target_image_path = target_image_path
        self.target_horde_path = target_horde_path
        self.target_image_night_path = target_image_night_path
        self.target_horde_night_path = target_horde_night_path
        self.target_no_pp_path = target_no_pp_path
        self.target_no_pp_night_path = target_no_pp_night_path
        self.overview_path = overview_path
        self.pokecenter_path = pokecenter_path
        self.pc_left_path = pc_left_path
        self.pc_right_path = pc_right_path
        self.stairs_i6_path = stairs_i6_path
        self.login_screen_path = login_screen_path
        self.login_2_path = login_2_path
        
        # Configurar umbrales de confianza
        self.threshold = 0.35  # Umbral de coincidencia para target_image
        self.horde_threshold = 0.6  # Umbral más estricto para horde
        self.overview_threshold = 0.3  # Umbral más bajo para overview
        self.pc_threshold = 0.9  # Umbral muy alto para PC left/right
        self.stairs_threshold = 0.4  # Umbral para stairs
        self.login_threshold = 0.45  # Umbral bajo para login screens
        self.last_pause_time = datetime.now()
        self.last_logout_time = datetime.now()
        self.is_logged_out = False
        
    def find_image(self, image_path, threshold):
        # Buscar la imagen objetivo en la pantalla
        location = pyautogui.locateOnScreen(image_path, confidence=threshold)
        
        if location is not None:
            # pyautogui.locateOnScreen devuelve una caja (left, top, width, height)
            # Devolvemos solo la coordenada top-left (x, y)
            return (location.left, location.top)
        return None

    def execute_sequence(self, sequence):
        """Ejecuta una secuencia de teclas"""
        for key in sequence:
            pyautogui.keyDown(key)
            time.sleep(random.randrange(12, 40)/100)
            pyautogui.keyUp(key)
            time.sleep(0.1)

    def execute_altsequence(self, sequence):
        """Ejecuta una secuencia de teclas"""
        time.sleep(3)
        for key in sequence:
            pyautogui.keyDown(key)
            time.sleep(random.randrange(12, 20)/100)
            pyautogui.keyUp(key)
            time.sleep(0.1)

    def execute_movesequence(self, sequence):
        """Ejecuta una secuencia de teclas"""
        for key in sequence:
            pyautogui.keyDown(key)
            time.sleep(random.randrange(24, 50)/100)
            pyautogui.keyUp(key)
            time.sleep(0.1)

    def execute_pc_1_sequence(self, sequence):
        """Ejecuta la salida de CENTRO POKEMON"""
        print("Ejecutando secuencia de pokecenter...")
        for key in sequence:
            pyautogui.keyDown(key)
            time.sleep(1.4)
            pyautogui.keyUp(key)
            time.sleep(0.1)

    def execute_pc_2_sequence(self, sequence):
        """Ejecuta la entrada a VIA ACUATICA"""
        print("Ejecutando secuencia de pokecenter...")
        for key in sequence:
            pyautogui.keyDown(key)
            time.sleep(2.6)
            pyautogui.keyUp(key)
            time.sleep(0.1)

    def execute_stairs_i6_sequence(self, sequence):
        """Ejecuta la secuencia de stairs_i6"""
        print("Ejecutando secuencia de stairs_i6...")
        for key in sequence:
            pyautogui.keyDown(key)
            time.sleep(1.0)  # 1 segundo exacto
            pyautogui.keyUp(key)
            time.sleep(0.1)

    def execute_logout_sequence(self, sequence):
        """Ejecuta la secuencia de logout"""
        print("Ejecutando secuencia de logout...")
        for key in sequence:
            pyautogui.keyDown(key)
            time.sleep(0.1)  # Presionar durante 0.1 segundos
            pyautogui.keyUp(key)
            time.sleep(0.1)  # Esperar 0.1 segundos

    def execute_login_sequence(self, sequence):
        """Ejecuta la secuencia de login"""
        print("Ejecutando secuencia de login...")
        for key in sequence:
            pyautogui.keyDown(key)
            time.sleep(0.1)  # Presionar durante 0.1 segundos
            pyautogui.keyUp(key)
            time.sleep(0.1)  # Esperar 0.1 segundos

    def check_pause(self):
        """Verifica si es hora de hacer una pausa o logout"""
        current_time = datetime.now()
        
        # Verificar si es hora de hacer logout (cada 10 horas)
        if not self.is_logged_out and current_time - self.last_logout_time >= timedelta(hours=10):
            print("\nHaciendo logout...")
            self.execute_logout_sequence(sequence_logout)
            self.is_logged_out = True
            print("Logout completado. Esperando para login...")
            return True
            
        # Verificar si es hora de hacer login (después de 75-120 minutos de logout)
        if self.is_logged_out and current_time - self.last_logout_time >= timedelta(minutes=random.randint(75, 120)):
            print("\nHaciendo login...")
            self.execute_login_sequence(sequence_login)
            self.is_logged_out = False
            self.last_logout_time = current_time
            print("Login completado. Reanudando...")
            return True
            
        # Verificar pausa normal (cada 10 minutos)
        if current_time - self.last_pause_time >= timedelta(minutes=10):
            pause_time = random.randint(30, 90)  # Pausa aleatoria entre 30 y 90 segundos
            print(f"\nHaciendo pausa de {pause_time} segundos...")
            time.sleep(pause_time)
            self.last_pause_time = current_time
            print("Pausa terminada. Reanudando...")
            return True
            
        return False

    def run(self, sequence, sequence_pp, sequence_not, altsequence, check_interval=1.0):
        """Ejecuta el bot continuamente"""
        print("Bot iniciado. Presiona Ctrl+C para detener.")
        no_detection_count = 0  # Contador de veces que no se detecta nada
        target_encounters = 0  # Contador de encuentros del objetivo
        try:
            while True:
                self.check_pause()  # Verificar si es hora de pausar
                
                # Verificar login_screen y login_2
                location_login_screen = self.find_image(self.login_screen_path, self.login_threshold)
                location_login_2 = self.find_image(self.login_2_path, self.login_threshold)
                
                if location_login_screen or location_login_2:
                    print("¡Pantalla de login detectada! Ejecutando secuencia de login...")
                    self.execute_login_sequence(sequence_login)
                    time.sleep(2)  # Esperar 2 segundos después del login
                else:
                    # Primero verificar PC left y right
                    location_pc_left = self.find_image(self.pc_left_path, self.pc_threshold)
                    location_pc_right = self.find_image(self.pc_right_path, self.pc_threshold)
                    
                    if location_pc_left:
                        print("PC izquierda detectada. Presionando tecla derecha...")
                        pyautogui.keyDown('right')
                        time.sleep(0.2)
                        pyautogui.keyUp('right')
                    elif location_pc_right:
                        print("PC derecha detectada. Presionando tecla izquierda...")
                        pyautogui.keyDown('left')
                        time.sleep(0.2)
                        pyautogui.keyUp('left')
                    else:
                        # Buscar no PP (día o noche)
                        location_no_pp = self.find_image(self.target_no_pp_path, self.threshold)
                        location_no_pp_night = self.find_image(self.target_no_pp_night_path, self.threshold)
                        
                        if location_no_pp or location_no_pp_night:
                            print("¡No PP detectado! Ejecutando secuencia PP...")
                            time.sleep(7)
                            self.execute_altsequence(sequence_pp)
                            time.sleep(5)
                            self.execute_altsequence(leppa_berry)
                            no_detection_count = max(0, no_detection_count - 4)  # Bajar 4 veces el contador
                        else:
                            # Buscar horda (día o noche)
                            location_horde = self.find_image(self.target_horde_path, self.horde_threshold)
                            location_horde_night = self.find_image(self.target_horde_night_path, self.horde_threshold)
                            
                            if location_horde or location_horde_night:
                                print("¡Horda detectada! Ejecutando secuencia de horda...")
                                self.execute_sequence(sequence_not)
                                no_detection_count = max(0, no_detection_count - 7)  # Bajar 7 veces el contador
                                time.sleep(3)
                            else:
                                # Verificar pokecenter
                                location_pokecenter = self.find_image(self.pokecenter_path, self.threshold)
                                if location_pokecenter:
                                    print("¡Pokecenter detectado!")
                                    self.execute_pc_1_sequence(sequence_pc_1)
                                    time.sleep(2)  # Tiempo de salida del centro pokemon
                                    self.execute_pc_2_sequence(sequence_pc_2)
                                else:
                                    # Buscar target (día o noche)
                                    location_image = self.find_image(self.target_image_path, self.threshold)
                                    location_image_night = self.find_image(self.target_image_night_path, self.threshold)
                                    
                                    if location_image or location_image_night:
                                        self.execute_sequence(sequence)
                                        print("¡Imagen objetivo detectada! Ejecutando secuencia principal...")
                                        no_detection_count = max(0, no_detection_count - 4) 
                                        time.sleep(1) # Bajar 4 veces el contador
                                        if location_image or location_image_night:
                                            time.sleep(3)
                                        
                                        # Incrementar contador de encuentros
                                        target_encounters += 1
                                        
                                        # Cada 10 encuentros, ejecutar tecla arriba
                                        if target_encounters % 10 == 0:
                                            print("10 encuentros completados. Ejecutando tecla arriba...")
                                            time.sleep(2)  # Esperar 2 segundos
                                            pyautogui.keyDown('up')
                                            time.sleep(0.6)  # Presionar durante 0.6 segundos
                                            pyautogui.keyUp('up')
                                    else:
                                        # Verificar stairs_i6 como última opción
                                        location_stairs_i6 = self.find_image(self.stairs_i6_path, self.stairs_threshold)
                                        if location_stairs_i6:
                                            print("¡Stairs i6 detectado!")
                                            self.execute_stairs_i6_sequence(sequence_stairs_i6)
                                        else:
                                            print("Ninguna imagen detectada. Ejecutando secuencia alternativa...")
                                            self.execute_movesequence(altsequence)
                                            no_detection_count += 1  # Incrementar contador cuando no se detecta nada
                                            
                                            # Verificar si está en overview y el contador llegó a 40
                                            location_overview = self.find_image(self.overview_path, self.overview_threshold)
                                            if location_overview and no_detection_count >= 40:
                                                print("En overview y 40 intentos sin detección. Moviendo hacia abajo...")
                                                pyautogui.keyDown('down')
                                                time.sleep(0.5)  # 500 milisegundos
                                                pyautogui.keyUp('down')
                                                no_detection_count = 0  # Reiniciar contador
                time.sleep(check_interval)
        except KeyboardInterrupt:
            print("\nBot detenido.")

if __name__ == "__main__":
    # Rutas de las imágenes
    login_screen = "login_screen.png"
    login_2 = "login_2.png"
    overview = "overview.png"
    pokecenter = "pokecenter.png"
    pc_left = "pc_left.png"
    pc_right = "pc_right.png"
    stairs_i6 = "stairs_i6.png"
    target_image = "target.png"
    target_image_day = "target_day.png"
    target_image_night = "target_night.png"
    target_horde = "horde.png"
    target_horde_night = "horde_night.png"
    target_no_pp = "no_pp.png"
    target_no_pp_night = "no_pp_night.png"
    
    # Define las secuencias de teclas
    leppa_berry = ['4', 'z', 'z', 'z'] # Secuencia
    sequence = ['up', 'left', 'z', 'z']  # Secuencia para target_image
    sequence_pp = ['x', 'right', 'right', 'right', 'z']  # Secuencia para no PP
    sequence_not = ['down', 'right', 'z']  # Secuencia para target_horde
    altsequence = ['left', 'right', 'left', 'right', "x"]  # Secuencia alternativa
    sequence_movedown = ['down', 'down', "x"]  # Secuencia alternativa
    sequence_pc_1 = ['down']
    sequence_pc_2 = ['1', 'right', 'down']
    sequence_stairs_i6 = ['down', 'right']
    sequence_logout = ['esc', 'down', 'down', 'down', 'down', 'z', 'z']
    sequence_login = ['z', 'z']
    
    try:
        bot = ImageBot(target_image, target_horde, target_image_night, target_horde_night, target_no_pp, target_no_pp_night, overview, pokecenter, pc_left, pc_right, stairs_i6, login_screen, login_2)
        time.sleep(3)
        bot.run(sequence, sequence_pp, sequence_not, altsequence, 0.1)
    except ValueError as e:
        print(f"Error: {e}")
        print("Asegúrate de que las imágenes existen en el directorio actual.") 