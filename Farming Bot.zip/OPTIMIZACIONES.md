# Optimizaciones de Búsqueda de Pokémon

## Resumen de Cambios

Se ha implementado un sistema de búsqueda optimizada que separa el proceso de detección por segundos con un máximo de 250 milisegundos por imagen.

## Nuevas Funcionalidades

### 1. Función `init_combat_optimized()`

**Características principales:**
- **Procesamiento por lotes**: Procesa imágenes en grupos configurables
- **Límite de tiempo por imagen**: Máximo 250ms por imagen individual
- **Límite de tiempo por lote**: Controla el tiempo total por lote de imágenes
- **Timeout global**: Evita búsquedas infinitas
- **Priorización inteligente**: Procesa primero Pokémon de tipo Grass

**Parámetros configurables:**
```python
init_combat_optimized(
    screenshot,           # Imagen de la pantalla
    threshold=0.65,      # Umbral de confianza
    batch_size=20,       # Imágenes por lote
    max_time_per_batch=5.0  # Tiempo máximo por lote
)
```

### 2. Archivo de Configuración (`config.py`)

**Secciones de configuración:**
- `DETECTION_CONFIG`: Umbrales y tiempos de detección
- `TIMING_CONFIG`: Configuración de pausas y delays
- `KEY_SEQUENCES`: Secuencias de teclas predefinidas
- `WINDOW_CONFIG`: Configuración de ventana de PokéMMO
- `OCR_CONFIG`: Configuración de reconocimiento de texto
- `LOGGING_CONFIG`: Configuración de logging
- `FILE_CONFIG`: Configuración de archivos e imágenes

### 3. Sistema de Timing Mejorado

**Control de tiempo por niveles:**
1. **Por imagen**: Máximo 250ms por imagen individual
2. **Por lote**: Máximo 5 segundos por lote de 20 imágenes
3. **Global**: Máximo 8 segundos para toda la búsqueda

**Beneficios:**
- Evita que una imagen lenta bloquee todo el proceso
- Permite procesar más imágenes en el mismo tiempo
- Mejor responsividad del bot

## Comparación de Rendimiento

### Método Original
- Procesa todas las imágenes secuencialmente
- Sin límites de tiempo por imagen
- Puede tardar mucho en imágenes complejas
- Tiempo total impredecible

### Método Optimizado
- Procesamiento por lotes con límites de tiempo
- Máximo 250ms por imagen
- Timeout global de 8 segundos
- Tiempo total más predecible y controlado

## Uso

### Ejecutar con configuración por defecto:
```python
from engine import init_combat_optimized
result = init_combat_optimized(screenshot)
```

### Ejecutar con configuración personalizada:
```python
result = init_combat_optimized(
    screenshot,
    threshold=0.7,
    batch_size=10,
    max_time_per_batch=3.0
)
```

### Ejecutar pruebas de rendimiento:
```python
python test_optimized_search.py
```

## Configuración Recomendada

### Para máxima velocidad:
```python
batch_size=10
max_time_per_batch=2.0
threshold=0.7
```

### Para máxima precisión:
```python
batch_size=50
max_time_per_batch=10.0
threshold=0.6
```

### Para balance velocidad/precisión:
```python
batch_size=20
max_time_per_batch=5.0
threshold=0.65
```

## Monitoreo y Logging

El sistema incluye logging detallado que muestra:
- Tiempo de procesamiento por imagen
- Tiempo de procesamiento por lote
- Advertencias cuando se acerca a los límites
- Estadísticas de rendimiento

## Archivos Modificados

1. **`engine.py`**: Nueva función `init_combat_optimized()`
2. **`config.py`**: Archivo de configuración centralizado
3. **`test_optimized_search.py`**: Script de pruebas
4. **`test.py`**: Actualizado para usar nuevas funciones

## Próximas Mejoras

- [ ] Implementar caché de imágenes procesadas
- [ ] Añadir detección paralela por hilos
- [ ] Optimizar templates más grandes automáticamente
- [ ] Añadir métricas de rendimiento en tiempo real
- [ ] Implementar aprendizaje automático para priorización

## Solución de Problemas

### Si la detección es muy lenta:
- Reducir `batch_size`
- Reducir `max_time_per_batch`
- Aumentar `threshold`

### Si la detección es muy rápida pero imprecisa:
- Aumentar `batch_size`
- Aumentar `max_time_per_batch`
- Reducir `threshold`

### Si hay errores de memoria:
- Reducir `batch_size`
- Verificar que las imágenes no sean demasiado grandes
