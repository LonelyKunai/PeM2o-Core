import engine as e
from test_optimized_search import test_optimized_search, compare_methods

# Ejecutar prueba de detección optimizada
print("🧪 Ejecutando pruebas de detección optimizada...")
test_optimized_search()

#print("\n" + "="*50)
#print("⚖️  Comparando métodos...")
#compare_methods()

# También ejecutar el método original si se desea
print("\n" + "="*50)
#print("🤖 Ejecutando bot original...")
#e.combat()  