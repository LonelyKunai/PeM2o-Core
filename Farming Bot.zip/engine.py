
from pynput.keyboard import Controller, Key
from time import sleep
import cv2
import numpy as np
import pyautogui
import os
import time
import pytesseract
from PIL import Image, ImageFont, ImageDraw
import shutil
import urllib.request
from config import DETECTION_CONFIG, TIMING_CONFIG, OCR_CONFIG, LOGGING_CONFIG, FILE_CONFIG

# Importar librerías de Windows (opcional)
try:
    import win32gui
    import win32con
    WINDOWS_APIS_AVAILABLE = True
except ImportError:
    print("⚠️  win32gui no disponible. Instala con: pip install pywin32")
    WINDOWS_APIS_AVAILABLE = False

# Configuración de Tesseract en Windows: intenta usar PATH y rutas comunes
tess_in_path = shutil.which("tesseract")
fallback_paths = [
    r"C:\\Program Files\\Tesseract-OCR\\tesseract.exe",
    r"C:\\Program Files (x86)\\Tesseract-OCR\\tesseract.exe",
]
tesseract_cmd = tess_in_path or next((p for p in fallback_paths if os.path.exists(p)), None)

# Configurar Tesseract
if tesseract_cmd:
    pytesseract.pytesseract.tesseract_cmd = tesseract_cmd
    print(f"✅ Tesseract encontrado en: {tesseract_cmd}")
    
    # Configurar TESSDATA_PREFIX para Windows
    tessdata_paths = [
        r"C:\\Program Files\\Tesseract-OCR\\tessdata",
        r"C:\\Program Files (x86)\\Tesseract-OCR\\tessdata",
        os.path.join(os.path.dirname(tesseract_cmd), "tessdata")
    ]
    
    tessdata_path = next((p for p in tessdata_paths if os.path.exists(p)), None)
    if tessdata_path:
        os.environ['TESSDATA_PREFIX'] = tessdata_path
        print(f"✅ TESSDATA_PREFIX configurado en: {tessdata_path}")
    else:
        print("⚠️  No se encontró la carpeta tessdata. El OCR puede no funcionar correctamente.")
        
    # Verificar que existe el archivo de idioma inglés
    eng_file = os.path.join(tessdata_path or "", "eng.traineddata")
    if not os.path.exists(eng_file):
        print(f"❌ No se encontró eng.traineddata en: {tessdata_path}")
        print("💡 Intentando descargar automáticamente...")
        
        try:
            # Descargar el archivo de idioma inglés
            url = "https://github.com/tesseract-ocr/tessdata/raw/main/eng.traineddata"
            print(f"📥 Descargando desde: {url}")
            urllib.request.urlretrieve(url, eng_file)
            print(f"✅ Archivo descargado exitosamente: {eng_file}")
        except Exception as download_error:
            print(f"❌ Error al descargar: {download_error}")
            print("💡 Descarga manualmente desde: https://github.com/tesseract-ocr/tessdata")
            print("   Y colócalo en la carpeta tessdata de Tesseract")
    else:
        print(f"✅ Archivo de idioma inglés encontrado: {eng_file}")
else:
    print("❌ Error: Tesseract no encontrado. Instálalo desde: https://github.com/UB-Mannheim/tesseract/wiki")
    print("💡 O agrega la ruta de Tesseract al PATH del sistema")

kb = Controller()

def find_pokemmo_window():
    """
    Encuentra la ventana de PokéMMO en el sistema.
    
    Returns:
        tuple: (hwnd, window_title) si se encuentra, (None, None) si no
    """
    if not WINDOWS_APIS_AVAILABLE:
        print("⚠️  APIs de Windows no disponibles, usando detección básica")
        return None, "PokéMMO (detección básica)"
    
    def enum_windows_callback(hwnd, windows):
        if win32gui.IsWindowVisible(hwnd):
            window_title = win32gui.GetWindowText(hwnd)
            if "PokeMMO" in window_title or "pokemmo" in window_title.lower():
                window_title = "PokeMMO"
                windows.append((hwnd, window_title))
        return True
    
    windows = []
    win32gui.EnumWindows(enum_windows_callback, windows)
    
    if windows:
        # Retornar la primera ventana encontrada
        return windows[0]
    return None, None

def focus_pokemmo_window():
    """
    Enfoca la ventana de PokéMMO y la trae al frente.
    
    Returns:
        bool: True si se pudo enfocar, False si no
    """
    hwnd, title = find_pokemmo_window()
    if hwnd and WINDOWS_APIS_AVAILABLE:
        try:
            # Restaurar la ventana si está minimizada
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            # Traer la ventana al frente
            win32gui.SetForegroundWindow(hwnd)
            print(f"✅ Ventana PokéMMO enfocada: {title}")
            return True
        except Exception as e:
            print(f"❌ Error al enfocar ventana PokéMMO: {e}")
            return False
    elif title:
        print(f"✅ Usando detección básica para: {title}")
        return True
    else:
        print("❌ No se encontró la ventana de PokéMMO")
        return False

def get_pokemmo_window_rect():
    """
    Obtiene las coordenadas de la ventana de PokéMMO.
    
    Returns:
        tuple: (x, y, width, height) de la ventana, o None si no se encuentra
    """
    hwnd, title = find_pokemmo_window()
    if hwnd and WINDOWS_APIS_AVAILABLE:
        try:
            rect = win32gui.GetWindowRect(hwnd)
            x, y, right, bottom = rect
            width = right - x
            height = bottom - y
            print(f"📐 Ventana PokéMMO: x={x}, y={y}, w={width}, h={height}")
            return (x, y, width, height)
        except Exception as e:
            print(f"❌ Error al obtener coordenadas de ventana: {e}")
            return None
    elif title:
        print(f"📐 Usando pantalla completa para: {title}")
        return (0, 0, 1920, 1080)  # Resolución por defecto
    return None


up = Key.up
down = Key.down
left = Key.left
right = Key.right
_a = '_a'
_b = '_b'
_c = '_c'
_d = '_d'
_e = '_e'
_f = '_f'
_g = '_g'
_h = '_h'
_i = '_i'
_j = '_j'
_k = '_k'
_l = '_l'
_m = '_m'
_n = '_n'
_o = '_o'
_p = '_p'
_q = '_q'
_r = '_r'
_s = '_s'
_t = '_t'
_u = '_u'
_v = '_v'
_w = '_w'
_x = '_x'
_y = '_y'
_z = '_z'


def press(key, seconds):
    kb.press(key)
    sleep(seconds)
    kb.release(key)
    print(f"Instruccion {key} completada.")

def sequence(keys, seconds, interval):
    if isinstance(keys, tuple):
        for i in keys:
            kb.press(i)
            sleep(seconds)
            kb.release(i)
            sleep(interval)
    elif isinstance(keys, str):
        kb.press(keys)
        sleep(seconds)
        kb.release(keys)
    elif hasattr(keys, '__iter__'):
        for key in keys:
            kb.press(key)
            sleep(seconds)
            kb.release(key)
            sleep(interval)
    else:
        print(f"{keys} no es valido")

def repeat(key, seconds, times, interval, sleeper):
    i = times
    original_key = key
    while times > 0:
        if type(key) == str and key.startswith('_'):
            actual_key = key[1:]
            kb.press(actual_key)
            sleep(seconds)
            kb.release(actual_key)
        else:
            kb.press(key)
            sleep(seconds)
            kb.release(key)
        times -= 1
        sleep(interval)
    sleep(sleeper)
    print(f"Instruccion {original_key} completado {i} veces.")


def init_combat_optimized(screenshot, threshold=0.65, batch_size=20, max_time_per_batch=5.0):
    """
    Versión optimizada de detección de Pokémon con procesamiento por lotes de tiempo.
    
    Args:
        screenshot: Imagen de la pantalla capturada
        threshold: Umbral de confianza para detección
        batch_size: Número de imágenes a procesar por lote
        max_time_per_batch: Tiempo máximo por lote en segundos
    """
    # Usar valores de configuración si no se proporcionan
    if threshold is None:
        threshold = DETECTION_CONFIG['thresholds']['pokemon']
    if batch_size is None:
        batch_size = DETECTION_CONFIG['timing']['batch_size']
    if max_time_per_batch is None:
        max_time_per_batch = DETECTION_CONFIG['timing']['max_time_per_batch']
    
    print("    🔍 Iniciando detección de Pokémon (modo optimizado por lotes)...")
    color_config = DETECTION_CONFIG['color_processing']
    if color_config['use_color']:
        print(f"    🎨 Modo: Detección a color ({color_config['color_mode']}) para máxima precisión")
    else:
        print("    ⚫ Modo: Detección en escala de grises")
    start_time = time.time()
    max_detection_time = DETECTION_CONFIG['timing']['max_detection_time']
    max_time_per_image = DETECTION_CONFIG['timing']['max_time_per_image']
    
    # Obtener todas las imágenes de la carpeta mons
    mons_dir = FILE_CONFIG['mons_directory']
    if not os.path.exists(mons_dir):
        print(f"    ❌ Error: No se encontró la carpeta {mons_dir}")
        time.sleep(10)
        return False
    
    # Obtener dimensiones de la pantalla
    screen_height, screen_width = screenshot.shape[:2]
    print(f"    📐 Pantalla: {screen_width}x{screen_height} píxeles")
    
    # Contar archivos de imágenes
    image_files = [f for f in os.listdir(mons_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))]
    print(f"    📁 Analizando {len(image_files)} imágenes de Pokémon...")
    
    # Priorizar Pokémon de tipo Grass y otros tipos comunes
    priority_files = [f for f in image_files if 'grs' in f.lower() or 'grass' in f.lower()]
    other_files = [f for f in image_files if f not in priority_files]
    
    # Combinar listas con prioridad
    image_files = priority_files + other_files
    print(f"    🌱 Priorizando {len(priority_files)} Pokémon de tipo Grass")
    print(f"    📦 Procesando en lotes de {batch_size} imágenes con máximo {max_time_per_batch}s por lote")
    
    # Procesar imágenes en lotes
    total_batches = (len(image_files) + batch_size - 1) // batch_size
    
    for batch_num in range(total_batches):
        batch_start_time = time.time()
        
        # Verificar timeout global
        if time.time() - start_time > max_detection_time:
            print(f"    ⏰ Timeout global alcanzado ({max_detection_time}s) - Deteniendo análisis")
            break
        
        # Obtener imágenes del lote actual
        start_idx = batch_num * batch_size
        end_idx = min(start_idx + batch_size, len(image_files))
        batch_images = image_files[start_idx:end_idx]
        
        print(f"    📦 Procesando lote {batch_num + 1}/{total_batches} ({len(batch_images)} imágenes)")
        
        # Procesar cada imagen del lote
        for i, filename in enumerate(batch_images, 1):
            # Verificar timeout del lote
            if time.time() - batch_start_time > max_time_per_batch:
                print(f"    ⏰ Timeout del lote alcanzado ({max_time_per_batch}s) - Saltando al siguiente lote")
                break
            
            # Iniciar timer para esta imagen específica
            image_start_time = time.time()
            
            template_path = os.path.join(mons_dir, filename)
            
            # Leer template (a color BGR)
            template = cv2.imread(template_path, cv2.IMREAD_COLOR)
            if template is None:
                continue
            
            template_height, template_width = template.shape[:2]
            
            # Verificar si el template es demasiado grande o pequeño
            if template_width > screen_width * 0.6 or template_height > screen_height * 0.6:
                continue
            if template_width < 30 or template_height < 30:
                continue
            
            # Optimización: Reducir tamaño de templates muy grandes
            if template_width > 200 or template_height > 200:
                scale_factor = min(200 / template_width, 200 / template_height)
                template = cv2.resize(template, None, fx=scale_factor, fy=scale_factor, interpolation=cv2.INTER_AREA)
                template_height, template_width = template.shape[:2]
            
            best_match = 0
            best_scale = 1.0
            best_location = None
            
            # Buscar en escalas optimizadas
            scales = [1]  # Solo escala 1.0x para máxima velocidad
            for scale in scales:
                # Verificar timeout por imagen
                if time.time() - image_start_time > max_time_per_image:
                    break
                    
                # Calcular nuevo tamaño
                new_width = int(template_width * scale)
                new_height = int(template_height * scale)
                
                # Verificar que el template escalado no sea más grande que la pantalla
                if new_width > screen_width or new_height > screen_height:
                    continue
                
                # Redimensionar template
                resized_template = cv2.resize(template, (new_width, new_height), interpolation=cv2.INTER_AREA)
                
                # Realizar template matching
                result = cv2.matchTemplate(screenshot, resized_template, cv2.TM_CCOEFF_NORMED)
                min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
                
                # Guardar el mejor match
                if max_val > best_match:
                    best_match = max_val
                    best_scale = scale
                    best_location = max_loc
                    
                    # Salida temprana si encontramos una coincidencia muy alta
                    if max_val > 0.85:
                        image_elapsed = time.time() - image_start_time
                        print(f"    🎯 ¡POKÉMON DETECTADO! {filename}")
                        print(f"    📊 Confianza: {best_match:.3f} | Escala: {best_scale:.1f}x | Posición: {best_location}")
                        print(f"    ⏱️  Tiempo de detección: {image_elapsed*1000:.1f}ms")
                        filename_type = (filename[4:])

                        match filename_type:
                            case "grs":
                                print("    🌱 ¡Pokémon de tipo Grass detectado! Iniciando combate...")
                                return True
                            case _:
                                print(f"    ℹ️  Pokémon detectado (tipo: {filename_type})")
                                return True
            
            # Verificar si encontramos una coincidencia válida
            if best_match >= threshold:
                image_elapsed = time.time() - image_start_time
                print(f"    🎯 ¡POKÉMON DETECTADO! {filename}")
                print(f"    📊 Confianza: {best_match:.3f} | Escala: {best_scale:.1f}x | Posición: {best_location}")
                print(f"    ⏱️  Tiempo de detección: {image_elapsed*1000:.1f}ms")
                filename_type = (filename[4:])

                match filename_type:
                    case "grs":
                        print("    🌱 ¡Pokémon de tipo Grass detectado! Iniciando combate...")
                        return True
                    case _:
                        print(f"    ℹ️  Pokémon detectado (tipo: {filename_type})")
                        return True
        
        # Mostrar estadísticas del lote
        batch_elapsed = time.time() - batch_start_time
        print(f"    📊 Lote {batch_num + 1} completado en {batch_elapsed:.2f}s")

    elapsed_time = time.time() - start_time
    print(f"    ❌ No se detectaron Pokémon en esta captura (tiempo total: {elapsed_time:.2f}s)")
    return False

def init_combat(screenshot, threshold=0.65):
    print("    🔍 Iniciando detección de Pokémon (modo optimizado por tiempo)...")
    color_config = DETECTION_CONFIG['color_processing']
    if color_config['use_color']:
        print(f"    🎨 Modo: Detección a color ({color_config['color_mode']}) para máxima precisión")
    else:
        print("    ⚫ Modo: Detección en escala de grises")
    start_time = time.time()
    max_detection_time = 8  # Máximo 8 segundos
    max_time_per_image = 0.25  # Máximo 250 milisegundos por imagen
    
    # Obtener todas las imágenes de la carpeta mons
    mons_dir = "mons"
    if not os.path.exists(mons_dir):
        print(f"    ❌ Error: No se encontró la carpeta {mons_dir}")
        time.sleep(10)
        return False
    
    # Obtener dimensiones de la pantalla
    screen_height, screen_width = screenshot.shape[:2]
    print(f"    📐 Pantalla: {screen_width}x{screen_height} píxeles")
    
    # Contar archivos de imágenes
    image_files = [f for f in os.listdir(mons_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))]
    print(f"    📁 Analizando {len(image_files)} imágenes de Pokémon...")
    
    # Priorizar Pokémon de tipo Grass y otros tipos comunes
    priority_files = [f for f in image_files if 'grs' in f.lower() or 'grass' in f.lower()]
    other_files = [f for f in image_files if f not in priority_files]
    
    # Combinar listas con prioridad
    image_files = priority_files + other_files
    print(f"    🌱 Priorizando {len(priority_files)} Pokémon de tipo Grass")
    
    # Escalas optimizadas (menos escalas para mayor velocidad)
    scales = [1]  # Escala 1.0x
    
    # Limitar el número de imágenes a analizar por tiempo
    max_images_per_cycle = len(image_files)
    image_files = image_files[:max_images_per_cycle]
    print(f"    ⚡ Analizando {len(image_files)} imágenes con límite de {max_time_per_image*1000:.0f}ms por imagen")
    
    # Buscar en todas las imágenes de la carpeta mons
    for i, filename in enumerate(image_files, 1):
        # Verificar timeout global
        if time.time() - start_time > max_detection_time:
            print(f"    ⏰ Timeout global alcanzado ({max_detection_time}s) - Deteniendo análisis")
            break
        
        # Iniciar timer para esta imagen específica
        image_start_time = time.time()
        
        if i % 50 == 0:  # Mostrar progreso cada 50 imágenes
            elapsed = time.time() - start_time
            print(f"    📊 Progreso: {i}/{len(image_files)} | Tiempo total: {elapsed:.1f}s")
        
        template_path = os.path.join(mons_dir, filename)
        
        # Leer template (a color BGR)
        template = cv2.imread(template_path, cv2.IMREAD_COLOR)
        if template is None:
            continue
        
        template_height, template_width = template.shape[:2]
        
        # Verificar si el template es demasiado grande o pequeño
        if template_width > screen_width * 0.6 or template_height > screen_height * 0.6:
            continue
        if template_width < 30 or template_height < 30:
            continue
        
        # Optimización: Reducir tamaño de templates muy grandes
        if template_width > 200 or template_height > 200:
            scale_factor = min(200 / template_width, 200 / template_height)
            template = cv2.resize(template, None, fx=scale_factor, fy=scale_factor, interpolation=cv2.INTER_AREA)
            template_height, template_width = template.shape[:2]
        
        best_match = 0
        best_scale = 1.0
        best_location = None
        
        # Buscar en escalas optimizadas
        for scale in scales:
            # Verificar timeout por imagen
            if time.time() - image_start_time > max_time_per_image:
                print(f"    ⏰ Timeout por imagen alcanzado ({max_time_per_image*1000:.0f}ms) - Saltando {filename}")
                break
                
            # Calcular nuevo tamaño
            new_width = int(template_width * scale)
            new_height = int(template_height * scale)
            
            # Verificar que el template escalado no sea más grande que la pantalla
            if new_width > screen_width or new_height > screen_height:
                continue
            
            # Redimensionar template
            resized_template = cv2.resize(template, (new_width, new_height), interpolation=cv2.INTER_AREA)
            
            # Realizar template matching
            result = cv2.matchTemplate(screenshot, resized_template, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
            
            # Guardar el mejor match
            if max_val > best_match:
                best_match = max_val
                best_scale = scale
                best_location = max_loc
                
                # Salida temprana si encontramos una coincidencia muy alta
                if max_val > 0.85:  # Umbral más alto para detección temprana
                    image_elapsed = time.time() - image_start_time
                    print(f"    🎯 ¡POKÉMON DETECTADO! {filename}")
                    print(f"    📊 Confianza: {best_match:.3f} | Escala: {best_scale:.1f}x | Posición: {best_location}")
                    print(f"    ⏱️  Tiempo de detección: {image_elapsed*1000:.1f}ms")
                    filename_type = (filename[4:])

                    match filename_type:
                        case "grs":
                            print("    🌱 ¡Pokémon de tipo Grass detectado! Iniciando combate...")
                            return True
                        case _:
                            print(f"    ℹ️  Pokémon detectado (tipo: {filename_type})")
                            return True
        
        # Verificar si encontramos una coincidencia válida
        if best_match >= threshold:
            image_elapsed = time.time() - image_start_time
            print(f"    🎯 ¡POKÉMON DETECTADO! {filename}")
            print(f"    📊 Confianza: {best_match:.3f} | Escala: {best_scale:.1f}x | Posición: {best_location}")
            print(f"    ⏱️  Tiempo de detección: {image_elapsed*1000:.1f}ms")
            filename_type = (filename[4:])

            match filename_type:
                case "grs":
                    print("    🌱 ¡Pokémon de tipo Grass detectado! Iniciando combate...")
                    return True
                case _:
                    print(f"    ℹ️  Pokémon detectado (tipo: {filename_type})")
                    return True
        
        # Mostrar tiempo de procesamiento de la imagen actual
        image_elapsed = time.time() - image_start_time
        if image_elapsed > max_time_per_image * 0.8:  # Si se acerca al límite
            print(f"    ⚠️  Imagen {filename} procesada en {image_elapsed*1000:.1f}ms (cerca del límite)")

    elapsed_time = time.time() - start_time
    print(f"    ❌ No se detectaron Pokémon en esta captura (tiempo total: {elapsed_time:.2f}s)")
    return False

def detect_combat_rectangles(screenshot):
    """
    Detecta automáticamente los rectángulos de combate específicos de PokéMMO.
    
    Args:
        screenshot: Imagen de la pantalla capturada
    
    Returns:
        list: Lista de diccionarios con información de rectángulos detectados
    """
    print("    🔍 Detectando rectángulos de combate de PokéMMO...")
    
    # Obtener dimensiones de la pantalla
    screen_height, screen_width = screenshot.shape[:2]
    
    # Obtener coordenadas de la ventana de PokéMMO
    window_rect = get_pokemmo_window_rect()
    if window_rect:
        window_x, window_y, window_w, window_h = window_rect
        print(f"    📐 Ventana PokéMMO: {window_w}x{window_h} en ({window_x}, {window_y})")
    else:
        print("    ⚠️  No se pudo obtener coordenadas de ventana, usando pantalla completa")
        window_x, window_y, window_w, window_h = 0, 0, screen_width, screen_height
    
    # Convertir a escala de grises
    gray = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
    
    # Detectar específicamente los botones de combate de PokéMMO
    # Los botones de PokéMMO suelen estar en la parte inferior central
    combat_rects = []
    
    # Área específica donde PokéMMO coloca los botones de combate
    # Típicamente en la parte inferior central de la ventana
    combat_area_y_start = int(screen_height * 0.7)  # 70% desde arriba
    combat_area_y_end = int(screen_height * 0.95)   # 95% desde arriba
    combat_area_x_start = int(screen_width * 0.1)   # 10% desde la izquierda
    combat_area_x_end = int(screen_width * 0.9)     # 90% desde la izquierda
    
    print(f"    🎯 Buscando en área de combate: x={combat_area_x_start}-{combat_area_x_end}, y={combat_area_y_start}-{combat_area_y_end}")
    
    # Recortar el área de combate
    combat_area = gray[combat_area_y_start:combat_area_y_end, combat_area_x_start:combat_area_x_end]
    
    # Aplicar filtros específicos para PokéMMO
    # Los botones de PokéMMO suelen tener bordes definidos
    edges = cv2.Canny(combat_area, 30, 100)
    
    # Encontrar contornos
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Filtrar contornos específicos de PokéMMO
    min_area = 2000   # Área mínima para botones de PokéMMO
    max_area = 50000  # Área máxima para botones de PokéMMO
    
    for contour in contours:
        # Aproximar el contorno a un polígono
        epsilon = 0.02 * cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, epsilon, True)
        
        # Verificar si es aproximadamente rectangular (4 vértices)
        if len(approx) == 4:
            # Obtener el rectángulo delimitador
            x, y, w, h = cv2.boundingRect(contour)
            area = w * h
            
            # Filtrar por área y proporción específica de PokéMMO
            if min_area < area < max_area and 0.5 < w/h < 4.0:
                # Ajustar coordenadas al área completa de la pantalla
                actual_x = x + combat_area_x_start
                actual_y = y + combat_area_y_start
                
                combat_rects.append({
                    'name': f'pokemmo_rect_{len(combat_rects)+1}',
                    'x': actual_x,
                    'y': actual_y,
                    'width': w,
                    'height': h,
                    'area': area,
                    'confidence': area / max_area
                })
    
    # Ordenar por confianza (área relativa)
    combat_rects.sort(key=lambda x: x['confidence'], reverse=True)
    
    # Limitar a los 4 mejores rectángulos
    combat_rects = combat_rects[:4]
    
    if combat_rects:
        print(f"    ✅ Detectados {len(combat_rects)} rectángulos de combate de PokéMMO:")
        for i, rect in enumerate(combat_rects, 1):
            print(f"      {i}. {rect['name']}: x={rect['x']}, y={rect['y']}, w={rect['width']}, h={rect['height']} (confianza: {rect['confidence']:.2f})")
    else:
        print("    ❌ No se detectaron rectángulos de combate de PokéMMO")
        # Fallback: usar rectángulos predeterminados específicos de PokéMMO
        print("    🔄 Usando rectángulos predeterminados de PokéMMO...")
        
        # Coordenadas típicas de los botones de combate en PokéMMO
        center_x = screen_width // 2
        bottom_y = int(screen_height * 0.85)  # 85% desde arriba (típico en PokéMMO)
        
        # Crear rectángulos predeterminados específicos de PokéMMO
        default_width = 180
        default_height = 40
        spacing_x = 200
        spacing_y = 50
        
        combat_rects = [
            {
                'name': 'pokemmo_fight',
                'x': center_x - spacing_x,
                'y': bottom_y,
                'width': default_width,
                'height': default_height,
                'area': default_width * default_height,
                'confidence': 0.8
            },
            {
                'name': 'pokemmo_pokemon',
                'x': center_x + spacing_x - default_width,
                'y': bottom_y,
                'width': default_width,
                'height': default_height,
                'area': default_width * default_height,
                'confidence': 0.8
            },
            {
                'name': 'pokemmo_bag',
                'x': center_x - spacing_x,
                'y': bottom_y + spacing_y,
                'width': default_width,
                'height': default_height,
                'area': default_width * default_height,
                'confidence': 0.8
            },
            {
                'name': 'pokemmo_run',
                'x': center_x + spacing_x - default_width,
                'y': bottom_y + spacing_y,
                'width': default_width,
                'height': default_height,
                'area': default_width * default_height,
                'confidence': 0.8
            }
        ]
        print(f"    📋 Creados {len(combat_rects)} rectángulos predeterminados de PokéMMO")
    
    return combat_rects

def is_pokemmo_in_combat(screenshot):
    """
    Detecta si PokéMMO está en estado de combate.
    
    Args:
        screenshot: Imagen de la pantalla capturada
        
    Returns:
        bool: True si está en combate, False si no
    """
    print("    🔍 Verificando estado de combate en PokéMMO...")
    
    # Obtener dimensiones de la pantalla
    screen_height, screen_width = screenshot.shape[:2]
    
    # Convertir a escala de grises
    gray = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
    
    # Buscar indicadores específicos de combate en PokéMMO
    # 1. Verificar si hay barras de HP/PP en la pantalla
    # 2. Verificar si hay botones de combate visibles
    # 3. Verificar si hay texto de combate
    
    # Área donde suelen aparecer las barras de HP en PokéMMO
    hp_area = gray[int(screen_height * 0.1):int(screen_height * 0.3), 
                   int(screen_width * 0.1):int(screen_width * 0.4)]
    
    # Área donde suelen aparecer los botones de combate
    combat_area = gray[int(screen_height * 0.7):int(screen_height * 0.95), 
                       int(screen_width * 0.1):int(screen_width * 0.9)]
    
    # Detectar si hay actividad en estas áreas
    hp_activity = np.mean(hp_area)
    combat_activity = np.mean(combat_area)
    
    print(f"    📊 Actividad HP: {hp_activity:.1f}, Actividad Combate: {combat_activity:.1f}")
    
    # Criterios para determinar si está en combate
    in_combat = (
        hp_activity > 50 and  # Hay barras de HP visibles
        combat_activity > 30   # Hay botones de combate visibles
    )
    
    if in_combat:
        print("    ✅ ¡PokéMMO está en combate!")
    else:
        print("    ❌ PokéMMO no está en combate")
    
    return in_combat

def combat(threshold=0.8, max_wait=10, templates_actions=None):
    """
    Función combinada que detecta Pokémon y ejecuta acciones de combate.
    Combina la funcionalidad de combat() y action() en una sola función.
    
    Args:
        threshold (float): Umbral de similitud para detección de imágenes (0.0 a 1.0)
        max_wait (int): Tiempo máximo de espera en segundos
        templates_actions (list): Lista opcional de tuplas (image_path, key, action_name)
    
    Returns:
        dict: Diccionario con los resultados de las detecciones y acciones
    """
    print("=" * 50)
    print("🤖 INICIANDO BOT DE FARMING DE POKÉMON PARA POKÉMMO")
    color_config = DETECTION_CONFIG['color_processing']
    if color_config['use_color']:
        print(f"🎨 MODO: Detección a color ({color_config['color_mode']}) para máxima precisión")
    else:
        print("⚫ MODO: Detección en escala de grises")
    print("=" * 50)
    
    print(f"⏱️  Tiempo máximo de espera: {max_wait} segundos")
    print(f"🎯 Umbral de detección: {threshold}")
    print(f"📁 Templates de acciones: {'Sí' if templates_actions else 'No'}")
    print("=" * 50)
    sleep(1)
    
    start_time = time.time()
    results = {}
    step_counter = 0
    
    while time.time() - start_time < max_wait:
        step_counter += 1
        elapsed_time = time.time() - start_time
        print(f"\n🔄 PASO {step_counter} - Tiempo transcurrido: {elapsed_time:.1f}s")
        print("-" * 30)
        
        # Capturar pantalla
        print("📸 Capturando pantalla...")
        screenshot = pyautogui.screenshot()
        screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        print("✅ Pantalla capturada exitosamente")
        
        # 1. Buscar Pokémon en la pantalla (usando versión optimizada)
        print("🔍 Buscando Pokémon en la pantalla...")
        pokemon_detected = init_combat_optimized(screenshot, threshold, batch_size=20, max_time_per_batch=5.0)
        if pokemon_detected:
            print("🎉 ¡POKÉMON DETECTADO! Iniciando secuencia de combate...")
            print("⚔️  Ejecutando acciones de combate automáticas...")
            results['pokemon_detected'] = True
            return results
        else:
            print("❌ No se detectó ningún Pokémon en esta captura")

        # 2. Si se proporcionan templates_actions, buscar imágenes específicas
        if templates_actions:
            print(f"🖼️  Buscando {len(templates_actions)} imágenes específicas...")
            for i, (image_path, key, action_name) in enumerate(templates_actions, 1):
                print(f"  📋 [{i}/{len(templates_actions)}] Buscando: {action_name}")
                
                # Leer template (a color BGR)
                print(f"    📂 Cargando template: {image_path}")
                template = cv2.imread(image_path, cv2.IMREAD_COLOR)
                if template is None:
                    print(f"    ❌ Error: No se pudo cargar la imagen {image_path}")
                    results[action_name] = False
                    continue
                print(f"    ✅ Template cargado exitosamente (a color BGR)")
                
                # Realizar template matching
                print(f"    🔍 Realizando template matching...")
                result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)
                min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
                
                success = max_val >= threshold
                print(f"    📊 Confianza: {max_val:.3f} (Umbral: {threshold})")
                
                if success:
                    print(f"    🎯 ¡IMAGEN DETECTADA! Ejecutando acción...")
                    print(f"    ⌨️  Presionando tecla: {key}")
                    press(key, 0.1)
                    print(f"    ✅ Acción completada")
                else:
                    print(f"    ❌ Imagen no detectada (confianza insuficiente)")
                
                results[action_name] = success
                if success:
                    print(f"    ⏳ Pausa entre acciones...")
                    sleep(1)  # Pausa entre acciones exitosas
        else:
            print("ℹ️  No hay templates de acciones configurados")

        # 3. Verificar estado de combate en PokéMMO
        print("📝 Verificando estado de combate en PokéMMO...")
        
        # Verificar si PokéMMO está en combate
        if is_pokemmo_in_combat(screenshot):
            print("  ✅ ¡PokéMMO está en combate! Detectando botones...")
            
            # Detectar automáticamente los rectángulos de combate de PokéMMO
            inner_rects = detect_combat_rectangles(screenshot)
            
            if inner_rects:
                print(f"  📋 Detectados {len(inner_rects)} botones de combate de PokéMMO")
                
                # Verificar si hay actividad en los rectángulos detectados
                total_activity = 0
                for rect in inner_rects:
                    area = screenshot[rect['y']:rect['y'] + rect['height'], 
                                    rect['x']:rect['x'] + rect['width']]
                    gray_area = cv2.cvtColor(area, cv2.COLOR_BGR2GRAY)
                    total_activity += np.mean(gray_area)
                
                avg_activity = total_activity / len(inner_rects)
                activity_threshold = 30
                print(f"  📊 Nivel de actividad promedio: {avg_activity:.1f} (Umbral: {activity_threshold})")
                
                if avg_activity > activity_threshold:
                    print("  ✅ ¡ÁREA DE COMBATE DETECTADA! Verificando texto en rectángulos internos...")
                    
                    # Verificar texto en cada rectángulo interno
                    for i, rect in enumerate(inner_rects, 1):
                        print(f"    📝 [{i}/{len(inner_rects)}] Analizando {rect['name']}...")
                        
                        # Extraer el área del rectángulo interno
                        print(f"      🔍 Extrayendo área: x={rect['x']}, y={rect['y']}, w={rect['width']}, h={rect['height']}")
                        inner_area = screenshot[rect['y']:rect['y'] + rect['height'], 
                                              rect['x']:rect['x'] + rect['width']]
                        
                        # Convertir a PIL Image para OCR
                        print(f"      🎨 Convirtiendo a PIL Image...")
                        inner_pil = Image.fromarray(cv2.cvtColor(inner_area, cv2.COLOR_BGR2RGB))
                        
                        try:
                            # Intentar OCR en el área
                            print(f"      🔤 Ejecutando OCR...")
                            
                            # Configuración de OCR más robusta
                            try:
                                text = pytesseract.image_to_string(inner_pil, config='--psm 6 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789')
                            except Exception as ocr_error:
                                print(f"      ⚠️  Error en OCR principal, intentando configuración alternativa...")
                                # Intentar con configuración más simple
                                text = pytesseract.image_to_string(inner_pil, config='--psm 6')
                            
                            text = text.strip()
                            
                            if text:
                                print(f"      📄 Texto detectado: '{text}'")
                                
                                # Ejecutar acciones basadas en el texto detectado
                                if "lucha" in text.lower() or "fight" in text.lower():
                                    print(f"      ⚔️  ¡OPCIÓN DE LUCHA DETECTADA! Ejecutando secuencia...")
                                    print(f"      ⌨️  Presionando: LEFT → UP → Z → Z")
                                    press(left, 0.1)
                                    sleep(0.1)
                                    press(up, 0.1)
                                    sleep(0.1)
                                    press(_z, 0.1)
                                    sleep(0.1)
                                    press(_z, 0.1)
                                    print(f"      ✅ Secuencia de lucha completada")
                                    results['lucha_detected'] = True
                                elif "Pokémon" in text.lower():
                                    print(f"      🔄 ¡OPCIÓN DE CAMBIO DETECTADA! Ejecutando...")
                                    print(f"      ⌨️  Presionando: DOWN → Z")
                                    press(down, 0.1)
                                    sleep(0.1)
                                    press(_z, 0.1)
                                    print(f"      ✅ Cambio de Pokémon completado")
                                    results['cambiar_detected'] = True
                                elif "MOCHILA" in text.lower() or "BAG" in text.lower():
                                    print(f"      🎒 ¡OPCIÓN DE OBJETO DETECTADA! Ejecutando...")
                                    print(f"      ⌨️  Presionando: RIGHT → Z")
                                    press(right, 0.1)
                                    sleep(0.1)
                                    press(_z, 0.1)
                                    print(f"      ✅ Uso de objeto completado")
                                    results['objeto_detected'] = True
                                elif "HUIDA" in text.lower() or "RUN" in text.lower():
                                    print(f"      🏃 ¡OPCIÓN DE HUIDA DETECTADA! Ejecutando...")
                                    print(f"      ⌨️  Presionando: DOWN → RIGHT → Z")
                                    press(down, 0.1)
                                    sleep(0.1)
                                    press(right, 0.1)
                                    sleep(0.1)
                                    press(_z, 0.1)
                                    print(f"      ✅ Huida completada")
                                    results['huida_detected'] = True
                                else:
                                    print(f"      ℹ️  Texto detectado pero no coincide con opciones conocidas")
                            else:
                                print(f"      ❌ No se detectó texto en este rectángulo")
                                    
                        except Exception as e:
                            print(f"      ❌ Error en OCR para {rect['name']}: {e}")
                            print(f"      💡 Sugerencia: Verifica que Tesseract esté instalado correctamente")
                            # Continuar con el siguiente rectángulo en lugar de fallar completamente
                            continue
                else:
                    print("  ❌ No hay actividad suficiente en los botones de combate")
            else:
                print("  ❌ No se detectaron botones de combate de PokéMMO")
        else:
            print("  ❌ PokéMMO no está en combate")
        
        # Resumen del paso
        print(f"\n📊 RESUMEN DEL PASO {step_counter}:")
        print(f"  🎯 Pokémon detectado: {'Sí' if 'pokemon_detected' in results else 'No'}")
        print(f"  🖼️  Imágenes procesadas: {len(templates_actions) if templates_actions else 0}")
        print(f"  ⏱️  Tiempo restante: {max_wait - elapsed_time:.1f}s")
        print("=" * 50)
    
    # Resumen final
    print(f"\n🏁 FINALIZANDO BOT - Tiempo total: {time.time() - start_time:.1f}s")
    print(f"📈 Resultados obtenidos: {len(results)} elementos")
    for key, value in results.items():
        print(f"  {key}: {'✅' if value else '❌'}")
    print("=" * 50)
    
    return results